local M = {}

local function degtorad(deg)
    local rad = math.pi*deg/180
    return rad
end

function M.calcSpread(api, count, spread)
    local length = 1 --扩散长度参数
    local div = 1 --扩散宽度参数
    local bullet_amount = 16 --与data一致
    local angle = 0

    if (api:getAttachment("MUZZLE")=="tacz:empty") or (api:getAttachment("MUZZLE")=="zeta:muzzle_duck") then
        length = 1.5 --扩散长度参数
        div = 0.375 --扩散宽度参数
        if (spread == 0) then --此spread==后面的数字需与data中的下蹲扩散相等
            angle = -60
            spread = 5
        end
        local offset = -0.5+0.5*(bullet_amount)
        local itp = (offset-count)/bullet_amount*spread/7.5
        local xx =math.cos(degtorad(angle))*itp*length+(math.random()-0.5)*div
        local yy =math.sin(degtorad(angle))*itp*length+(math.random()-0.5)*div
        return {xx,yy}
    else
        spread = 1.5
        if (api:getAttachment("MUZZLE")=="zeta:muzzle_half") then
            spread = spread * 0.45
        elseif (api:getAttachment("MUZZLE")=="zeta:muzzle_full") then
            spread = spread * 0.25
        end
        local xx =(math.random()-0.5)*spread
        local yy =(math.random()-0.5)*spread
        return {xx,yy}
    end
end

function M.modify_property(api, id, original)
    local cache = api:getCachedScriptData()
    if (id == "bullet_amount") then
        local mag = api:getAttachment("EXTENDED_MAG")
        if (mag == "tacz:ammo_mod_he") then
            return 16
        elseif (mag == "tacz:ammo_mod_hp") then
            return 16
        end
    end
    return original
end

return M