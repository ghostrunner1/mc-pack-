local M = {}

local function safeTimestamp(api)
    local safe, time = pcall(api.getRealSystemTimestamp, api)
    if safe then
        return time
    else
        return nil
    end
end

local function GetTimestamp(api)
    return safeTimestamp(api) or api:getCurrentTimestamp()
end

function M.start_reload(api)
    return false
end

function M.shoot(api)
    api:shootOnce(false)
end

local function tick_locked(api, heatTimestamp)
    local delay = api:getCoolingDelay()
    local now = api:getCurrentTimestamp()
    local last = api:getLastShootTimestamp()

    if now - last >= delay then
        local heat = api:getHeatAmount() - 2
        api:setHeatAmount(heat)
        if heat<=0 then
            api:setOverheatLocked(false);
        end
    end
end

local function tick_normal(api, heatTimestamp)
    api:setHeatAmount(0)
end

local function getProcessedTimestamp(api)
    local timestamp = GetTimestamp(api) - 1753977600000 -- 2025年8月1日00:00时间戳
    timestamp = math.floor(timestamp/100)--以分秒为单位
    return timestamp
end

local function ammoTimestampFix(api)
    api:removeAmmoFromMagazine(2147483647)
    api:putAmmoInMagazine(getProcessedTimestamp(api))
end

local function heatFeedback(api, heatTimestamp)
    local ammoTimestamp = api:getAmmoAmount()
    local trueTimestamp = getProcessedTimestamp(api)
    local TimestampFrameGap = (trueTimestamp - ammoTimestamp)*100 -- 单位是分秒,换算成毫秒
    local heat = api:getHeatAmount()
    local delay = api:getCoolingDelay()
    if (api:isOverheatLocked()) then
        heat = heat - math.max(0,TimestampFrameGap-delay)*2/50 -- 每50毫秒为一帧
    end
    api:setHeatAmount(heat)
    if heat<=0 then
        api:setOverheatLocked(false);
    end
end

function M.tick_heat(api, heatTimestamp)
    local cache = api:getCachedScriptData()
    if (cache == nil) then --如果没有就先初始化
        cache = {
            initial = false, -- 初始化
            is_tactical = api:getReloadStateType() == TACTICAL_RELOAD_FEEDING,
            needed_count = 1
        }
    end
    if not(cache.initial)then
        cache.initial = true
        heatFeedback(api, heatTimestamp)
    end
    api:cacheScriptData(cache)
    ammoTimestampFix(api)
    if api:hasHeatData() then
        if api:isOverheatLocked() then
            tick_locked(api, heatTimestamp)
        else
            tick_normal(api, heatTimestamp)
        end
    end
end

-- 警告，此方法是shootOnce的一部分，不要在此处尝试射击，不然会死循环
function M.handle_shoot_heat(api)
    if api:hasHeatData() then
        local heatMax = api:getHeatMax()
        local heat = math.min(api:getHeatAmount() + api:getHeatPerShot(), heatMax)
        api:setHeatAmount(heat)
        if heat >= heatMax then
            api:setOverheatLocked(true);
        end
    end
end

return M