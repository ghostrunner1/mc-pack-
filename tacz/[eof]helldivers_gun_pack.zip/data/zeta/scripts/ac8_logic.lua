local M = {}

function M.shoot(api)
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            frag_count = 0
        }
    end
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    if api:getFireMode() == AUTO then
        cache.frag_count = 30
    else
        cache.frag_count = 0
    end
    api:cacheScriptData(cache)
end
function M.modify_property(api, id, original)
    local mode = api:getFireMode()
    local cache = api:getCachedScriptData()
    if (id == "explosion_radius") then
        if mode == AUTO then
            return original * 1.5
        end
    elseif (id == "explosion_damage") then
        if mode == AUTO then
            return original * 190 / 150
        end
    elseif (id == "damge") then
        if mode == AUTO then
            return original * 150 / 325
        end
    elseif (id == "gunsmithlib_proximity_fuse_distance") then
        if mode == AUTO then
            return 2
        end
    elseif (id == "gunsmithlib_frag_count") then
        return cache.frag_count
    elseif (id == "gunsmithlib_safety_distance") then
        if mode == AUTO then
            return 4
        end
    end
    return original
end

function M.start_reload(api)
    if api:getAmmoAmount() > 5 then
        return false
    end
    local cache = {
        reloaded_count = 0,
        needed_count = 1,
        is_tactical = api:getAmmoAmount() ~= 0,
        interrupted_time = -1,
    }
    if cache.is_tactical then
        cache.needed_count = 1
    end
    api:cacheScriptData(cache)
    return true
end

local function getReloadTimingFromParam(param)
    -- Need to convert time from seconds to milliseconds
    local intro_empty = param.intro_empty * 1000
    local intro = param.intro * 1000
    local loop = param.loop * 1000
    local ending = param.ending * 1000
    local intro_empty_feed = param.intro_empty_feed * 1000
    local loop_feed = param.loop_feed * 1000
    -- Check if any timing is nil
    if (intro_empty == nil or intro == nil or loop == nil or ending == nil or intro_empty_feed == nil or loop_feed == nil) then
        return nil
    end
    return intro_empty, intro, loop, ending, intro_empty_feed, loop_feed
end

function M.tick_reload(api)
    -- Get all timings from script parameter in gun data
    local param = api:getScriptParams();
    local intro_empty, intro, loop, ending, intro_empty_feed, loop_feed = getReloadTimingFromParam(param)
    if (intro_empty == nil) then
        return NOT_RELOADING, -1
    end
    -- Get reload time (The time from the start of reloading to the current time) from api
    local reload_time = api:getReloadTime()
    -- Get cache from api, it will be used to count loaded ammo, mark reload interruptions, etc.
    local cache = api:getCachedScriptData()
    local interrupted_time = cache.interrupted_time
    -- Handle interrupting reload
    if (interrupted_time ~= -1) then
        local int_time = reload_time - interrupted_time
        if (int_time >= ending) then
            return NOT_RELOADING, -1
        else
            if (cache.is_tactical) then
                return TACTICAL_RELOAD_FINISHING, ending - int_time
            else
                return EMPTY_RELOAD_FINISHING, ending - int_time
            end
        end
    else
        -- if there is no ammo to consume, interrupt reloading
        if (not api:hasAmmoToConsume()) then
            interrupted_time = api:getReloadTime()
        end
    end
    -- Put an ammo into the barrel first
    local reloaded_count = cache.reloaded_count;
    if (reloaded_count == 0) then
        if (not cache.is_tactical) then
            if (reload_time > intro_empty_feed) then
                api:consumeAmmoFromPlayer(1)
                api:putAmmoInMagazine(5)
                reloaded_count = reloaded_count + 1
            end
        else
            reloaded_count = reloaded_count + 1
        end
    end
    -- Load the ammo into the magazine one by one
    if (reloaded_count > 0) then
        local base_time = (reloaded_count -1) * loop + loop_feed
        if (not cache.is_tactical) then
            base_time = base_time + intro_empty
        else
            base_time = base_time + intro
        end
        while (base_time < reload_time) do
            if (reloaded_count > cache.needed_count) then
                break
            end
            reloaded_count = reloaded_count + 1
            base_time = base_time + loop
            api:consumeAmmoFromPlayer(1)
            api:putAmmoInMagazine(5)
        end
    end
    -- Write back cache
    if (reloaded_count > cache.needed_count) then
        interrupted_time = api:getReloadTime() - loop_feed + loop
    end
    cache.interrupted_time = interrupted_time
    cache.reloaded_count = reloaded_count
    api:cacheScriptData(cache)
    -- return reloadstate
    local total_time = cache.needed_count * loop
    if (not cache.is_tactical) then
        total_time = total_time + intro_empty
        return EMPTY_RELOAD_FEEDING, total_time - reload_time
    else
        total_time = total_time + intro
        return TACTICAL_RELOAD_FEEDING, total_time - reload_time
    end
end

function M.interrupt_reload(api)
    local cache = api:getCachedScriptData()
    if (cache ~= nil and cache.interrupted_time == -1) then
        cache.interrupted_time = api:getReloadTime()
    end
end

return M