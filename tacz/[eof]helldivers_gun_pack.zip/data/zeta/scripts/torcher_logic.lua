local M = {}

function M.shoot(api)
    local cache = api:getCachedScriptData()
    if cache == nil then
        cache = {
            random = 0
        }
    end
    for i = 1, 10, 1 do
        cache.random = math.random()
        api:shootOnce((i == 1) and api:isShootingNeedConsumeAmmo() or false)
    end
    api:cacheScriptData(cache)
end

function M.modify_property(api, id, original)
    local cache = api:getCachedScriptData()
    if (id == "ignite_block") then
        if api:getAttachment("STOCK") == "zeta:stock_sup11" then
            if cache.random <= 0.3 then
                return true
            end
        end
    elseif (id == "ignite_entity_time") then
        if api:getAttachment("STOCK") == "zeta:stock_sup11" then
            return original * 3
        end
    elseif (id == "bullet_gravity") then
        if api:getAttachment("STOCK") == "zeta:stock_sup11" then
            return 1.25
        else
            return 0
        end
    end
    return original
end

return M