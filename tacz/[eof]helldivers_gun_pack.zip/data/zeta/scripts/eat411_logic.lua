local M = {}

local function GunsmithLibShooterStateAllowed()
    if GUNSMITHLIB_INSTALLED == nil then
        return false
    end
    if (GUNSMITHLIB_MAJOR_VERSION > 6) then
        return true
    elseif (GUNSMITHLIB_MAJOR_VERSION == 6) and (GUNSMITHLIB_MINOR_VERSION >= 1) then
        return true
    else
        return false
    end
end

local function safeGetExtension(api)
    local safe, ext = pcall(api.gunsmithlib_extension, api)
    if safe then
        return ext
    else
        return nil
    end
end

function M.tick_heat(api, heatTimestamp)
    if GunsmithLibShooterStateAllowed then
        local ext = safeGetExtension(api) or nil
        if ext ~= nil then
        local ext = api:gunsmithlib_extension()
            if (api:isReloadingNeedConsumeAmmo()) and (api:getAmmoAmount() == 0) then
                if not api:hasAmmoToConsume() then
                    ext:discard_weapon()
                end
            end
        end
    end
end

return M