local M = {}

function M.shoot(api)
    local mode = api:getFireMode()
    if mode == BURST then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
        api:shootOnce(api:isShootingNeedConsumeAmmo())
    else
        api:shootOnce(api:isShootingNeedConsumeAmmo())
    end
end

return M