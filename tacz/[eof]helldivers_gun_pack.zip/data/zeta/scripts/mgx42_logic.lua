local M = {}

function M.start_reload(api)
    if api:getAmmoAmount() == 0 then
        return true
    else
        local cache = api:getCachedScriptData()
        if api:getCurrentTimestamp()-(cache.reload_timestamp) <= 500 then
            cache.reload_timestamp = -1
            return true
        else
            cache.reload_timestamp = api:getCurrentTimestamp()
        end
        api:cacheScriptData(cache)
    end
    return false
end

local function GunsmithLibShooterStateAllowed()
    if GUNSMITHLIB_INSTALLED == nil then
        return false
    end
    if (GUNSMITHLIB_MAJOR_VERSION > 6) then
        return true
    elseif (GUNSMITHLIB_MAJOR_VERSION == 6) and (GUNSMITHLIB_MINOR_VERSION >= 1) then
        return true
    else
        return false
    end
end

local function safeGetExtension(api)
    local safe, ext = pcall(api.gunsmithlib_extension, api)
    if safe then
        return ext
    else
        return nil
    end
end

function M.tick_heat(api, heatTimestamp)
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            reload_timestamp = -1
        }
    end
    api:cacheScriptData(cache)

    if GunsmithLibShooterStateAllowed then
        local ext = safeGetExtension(api) or nil
        if ext ~= nil then
            if (api:isReloadingNeedConsumeAmmo()) and (api:getAmmoAmount() == 0) then
                if not api:hasAmmoToConsume() then
                    ext:discard_weapon()
                end
            end
        end
    end
end

return M