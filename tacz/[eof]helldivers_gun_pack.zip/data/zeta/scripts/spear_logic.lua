local M = {}

local function GunsmithLibSearchAllowed()
    if GUNSMITHLIB_INSTALLED == nil then
        return false
    end
    if (GUNSMITHLIB_MAJOR_VERSION > 6) then
        return true
    elseif (GUNSMITHLIB_MAJOR_VERSION == 6) and (GUNSMITHLIB_MINOR_VERSION >= 2) then
        return true
    else
        return false
    end
end

function M.tick_heat(api, heatTimestamp)
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            last_search = nil
        }
        api:setHeatAmount(0)
    end

    if (api:getAimingProgress() >= 1)then
        local locking = false
        if GunsmithLibSearchAllowed()and(api:getFireMode()==SEMI) then
            local ext = api:gunsmithlib_extension()
            local search = ext:search()
            local search_result = nil
            if search ~= nil then
                search_result = search:target_entity()
            else
                locking = false
            end
            if (cache.last_search == search_result)and(cache.last_search ~= nil) then
                locking = true
            end
            if search_result ~= nil then
                cache.last_search = search_result
            end
        else
            locking = true
        end

        local heat = api:getHeatAmount()
        if locking and (api:getAmmoAmount()>0) then
            local result = math.min(1, heat + 0.05)
            api:setHeatAmount(result)
        else
            api:setHeatAmount(0)
        end
    else
        api:setHeatAmount(0)
    end
    
    local heatlock = (api:getHeatAmount() < 1)
    api:setOverheatLocked(heatlock)
    

    api:cacheScriptData(cache)
end

function M.shoot(api)
    local cache = api:getCachedScriptData()
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    api:cacheScriptData(cache)
end

function M.calcSpread(api, count, spread)
    if GunsmithLibSearchAllowed()and(api:getFireMode()==SEMI) then
        local xx =(math.random()-0.5)*spread
        local yy =(math.random()-0.5)*spread + math.tan(math.rad(17.5))*8
        return {xx,yy}
    end
    return nil
end

function M.handle_shoot_heat(api)
end

return M