local M = {}

function M.shoot(api)
    local cache = api:getCachedScriptData()
    if (EXCEPTION_API_EXTENSION_INSTALLED and EXCEPTION_API_EXTENSION_VERSION >= 2) then
        local link = 1
        local decay = 0.5
        if api:getAttachment("STOCK") == "zeta:stock_sup13" then
            link = 3
            decay = 0.25
        end
        api:dealDamageToClosestEntityByLightningChain(55, 10, api:getFinalDamage() * (1 + cache.combo_percent/100), link, 20, decay, 0xEFFEFF, true, 1.8, 0)
        if (api:isShootingNeedConsumeAmmo()) then
            api:setAmmoInBarrel(false)
        end
    else
        api:shootOnce(false)
    end

    if api:getAttachment("STOCK") == "zeta:stock_sup13" then
        cache.combo_percent = math.min(cache.combo_percent + 50 , 100)
    end
    api:safeAsyncTask(function ()
        api:putAmmoInMagazine(1)
        return true
    end,1000,0,1)
    api:cacheScriptData(cache)
end

function M.tick_heat(api, heatTimestamp)
    if (api:getAmmoAmount()==0)and(api:hasAmmoInBarrel()==false) then
        api:putAmmoInMagazine(1)
    end
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            combo_percent = 0
        }
    end
    local t1 = api:getLastShootTimestamp()
    local t2 = api:getCurrentTimestamp()
    local combo_percent = cache.combo_percent or 0
    if (combo_percent > 0)and((t2 - t1 > 4000)) then
        combo_percent = math.max(combo_percent - 1 , 0)
    end
    api:cacheScriptData(cache)
end

function M.modify_property(api, id, original)
    local mode = api:getFireMode()
    if (id == "damage") then
        if api:getAttachment("STOCK") == "zeta:stock_sup13" then
            local cache = api:getCachedScriptData()
            return original * (1 + cache.combo_percent/100)
        end
    end
    return original
end

function M.start_reload(api)
    return false
end

return M