local M = {}

local function safeTimestamp(api)
    local safe, time = pcall(api.getRealSystemTimestamp, api)
    if safe then
        return time
    else
        return nil
    end
end

local function GetTimestamp(api)
    return safeTimestamp(api) or api:getCurrentTimestamp()
end

-- 尝试开火射击时调用
function M.shoot(api)
    api:shootOnce(false)
end

function M.start_reload(api)
    -- Initialize cache that will be used in reload ticking
    local cache = api:getCachedScriptData()
    cache.is_tactical = not(api:isOverheatLocked())
    cache.needed_count = 1
    api:cacheScriptData(cache)
    -- Return true to start ticking
    return true
end

function M.tick_reload(api)
    local cache = api:getCachedScriptData()

    local empty_cooldown = api:getScriptParams().empty_cooldown * 1000
    local empty_feed = api:getScriptParams().empty_feed * 1000
    local reload_cooldown = api:getScriptParams().reload_cooldown * 1000
    local reload_feed = api:getScriptParams().reload_feed * 1000
    local reload_time = api:getReloadTime()

    if (not cache.is_tactical) then
        if (reload_time < empty_feed) then
            return TACTICAL_RELOAD_FEEDING, empty_feed - reload_time
        elseif (reload_time >= empty_feed and reload_time < empty_cooldown) then
            if (cache.needed_count > 0) then
                api:consumeAmmoFromPlayer(cache.needed_count)
                cache.needed_count = 0
            end
            api:setHeatAmount(0)
            api:setOverheatLocked(false)
            return TACTICAL_RELOAD_FINISHING, empty_cooldown - reload_time
        else
            return NOT_RELOADING, -1
        end
    else
        if (reload_time < reload_feed) then
            return EMPTY_RELOAD_FEEDING, reload_feed - reload_time
        elseif (reload_time >= reload_feed and reload_time < reload_cooldown) then
            if (cache.needed_count > 0) then
                api:consumeAmmoFromPlayer(cache.needed_count)
                cache.needed_count = 0
            end
            api:setHeatAmount(0)
            api:setOverheatLocked(false)
            return EMPTY_RELOAD_FINISHING, reload_cooldown - reload_time
        else
            return NOT_RELOADING, -1
        end
    end
end

local function getCoolingValue(api)
    local param = api:getScriptParams()
    local base_cooling = param.cooldown
    local maxHeatSheet = {1, param.maxMag1, param.maxMag2, param.maxMag3}
    local coolingSheet = {1, param.coolingMag1, param.coolingMag2, param.coolingMag3}
    local max = 1
    local cooling = 1

    if api:getAttachment("EXTENDED_MAG")=="zeta:ice_hl"then
        max = maxHeatSheet[2]
        cooling = coolingSheet[2]
    elseif api:getAttachment("EXTENDED_MAG")=="zeta:ice_he"then
        max = maxHeatSheet[3]
        cooling = coolingSheet[3]
    elseif api:getAttachment("EXTENDED_MAG")=="zeta:ice_bl"then
        max = maxHeatSheet[4]
        cooling = coolingSheet[4]
    elseif api:getAttachment("EXTENDED_MAG")=="zeta:ice_qh"then
        max = param.maxQuickHeat
        cooling = param.coolingQuickHeat
    elseif api:getAttachment("EXTENDED_MAG")=="zeta:ice_sf"then
        max = param.maxSafe
        cooling = param.coolingSafe
    end

    if max == nil then max = 1 end
    if cooling == nil then cooling = 1 end

    return max, base_cooling * cooling
end

local function tick_normal(api, heatTimestamp)
    local param = api:getScriptParams()
    local max, cooling = getCoolingValue(api)
    local delay = api:getCoolingDelay()
    local now = api:getCurrentTimestamp()
    local last = api:getLastShootTimestamp()

    if now - last >= delay then
        local heat = api:getHeatAmount() - cooling/max
        api:setHeatAmount(heat)
    end
end

local function tick_locked(api, heatTimestamp)
    api:setHeatAmount(api:getHeatMax())
end

local function getProcessedTimestamp(api)
    local timestamp = GetTimestamp(api) - 1753977600000 -- 2025年8月1日00:00时间戳（ms）
    timestamp = math.floor(timestamp/100)--以分秒为单位
    return timestamp
end

local function ammoTimestampFix(api)
    api:removeAmmoFromMagazine(2147483647)
    if not api:isOverheatLocked()then
        api:putAmmoInMagazine(getProcessedTimestamp(api))
    end
end

local function heatFeedback(api, heatTimestamp)
    local max, cooling = getCoolingValue(api)
    local ammoTimestamp = api:getAmmoAmount()
    local trueTimestamp = getProcessedTimestamp(api)
    local TimestampFrameGap = (trueTimestamp - ammoTimestamp)*100 -- 单位是分秒,换算成毫秒
    local heat = api:getHeatAmount()
    local delay = api:getCoolingDelay()
    if not(api:isOverheatLocked()) then
        heat = heat - math.max(0,TimestampFrameGap-delay)*(cooling/max)/50 -- 每50毫秒为一帧
    end
    api:setHeatAmount(heat)
end

function M.tick_heat(api, heatTimestamp)
    local cache = api:getCachedScriptData()
    if (cache == nil) then --如果没有就先初始化
        cache = {
            initial = false, -- 初始化
            is_tactical = api:getReloadStateType() == TACTICAL_RELOAD_FEEDING,
            needed_count = 1
        }
    end
    if not(cache.initial)then
        cache.initial = true
        heatFeedback(api, heatTimestamp)
    end
    api:cacheScriptData(cache)
    ammoTimestampFix(api)
    if api:hasHeatData() then
        if api:isOverheatLocked() then
            tick_locked(api, heatTimestamp)
        else
            tick_normal(api, heatTimestamp)
        end
    end
end

local function getHeatSafeValue(api)
    local param = api:getScriptParams()
    local safeThreshold = 1
    local safeLimit = 1
    if api:getAttachment("EXTENDED_MAG")=="zeta:ice_sf"then
        safeThreshold = param.safeThreshold
        safeLimit = param.safeLimit
    end
    if safeThreshold == nil then safeThreshold = 0 end
    if safeLimit == nil then safeLimit = 0 end

    local heatshot_mult = 1
    if (api:getHeatAmount()/api:getHeatMax() >= safeThreshold)and(safeThreshold ~= 0) then
        heatshot_mult = 1 + (safeLimit - 1) * (api:getHeatAmount() - safeThreshold) / (api:getHeatMax() - safeThreshold)
    end
    return heatshot_mult
end

-- 警告，此方法是shootOnce的一部分，不要在此处尝试射击，不然会死循环
function M.handle_shoot_heat(api)
    if api:hasHeatData() then
        local max, cooling = getCoolingValue(api)
        local heatMax = api:getHeatMax()

        local heatshot_mult = getHeatSafeValue(api)

        local heatThisShot = api:getHeatPerShot() * heatshot_mult
        local heat = math.min(api:getHeatAmount() + heatThisShot/max, heatMax)
        api:setHeatAmount(heat)
        if heat >= heatMax then
            api:setOverheatLocked(true);
        end
    end
end

function M.modify_property(api, id, original)
    local mode = api:getFireMode()
    if (id == "ignite_entity") then
        if api:getAttachment("STOCK") == "zeta:stock_sup12" then
            if api:getHeatAmount()/api:getHeatMax() >=0.5 then
                return true
            end
        end
    elseif (id == "damage") then
        local mult = 1
        if api:getAttachment("STOCK") == "zeta:stock_sup12" then
            mult = mult + api:getHeatAmount()/api:getHeatMax() * 0.25
        end
        if api:getAttachment("MUZZLE") == "zeta:muzzle_resonance_lens" then
            local max, cooling = getCoolingValue(api)
            cooling = 1.6
            local heat = api:getHeatAmount() - cooling/max
            api:setHeatAmount(heat)
        end
        if api:getAttachment("EXTENDED_MAG") == "zeta:ice_sf" then
            mult = mult * getHeatSafeValue(api)
        end
        return original * mult
    end
    return original
end

return M