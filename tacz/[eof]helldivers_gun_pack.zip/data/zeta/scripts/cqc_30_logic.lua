local M = {}

local function GunsmithLibShooterStateAllowed()
    if GUNSMITHLIB_INSTALLED == nil then
        return false
    end
    if (GUNSMITHLIB_MAJOR_VERSION > 6) then
        return true
    elseif (GUNSMITHLIB_MAJOR_VERSION == 6) and (GUNSMITHLIB_MINOR_VERSION >= 1) then
        return true
    else
        return false
    end
end

function M.start_reload(api)
    local cache = api:getCachedScriptData()
    if (EXCEPTION_API_EXTENSION_INSTALLED and EXCEPTION_API_EXTENSION_VERSION >= 2) then
        local power = 1
        if GunsmithLibShooterStateAllowed then
            local ext = api:gunsmithlib_extension()
            local shooter = ext:shooter_states()
            local rotation = shooter:rotation_degrees()
            local pitch = rotation.x
            if pitch < 0 then
                power = 0.1 + 1.3 * math.cos(math.rad(pitch))
            else
                power = 1.4
            end
        end
        if (api:getAimingProgress() >=0.3) and (api:getAttachment("GRIP") == "zeta:stock_sh20") and (cache.dash_time <= 0) then
            api:kickbackPlayer(false, power)
            cache.dash_time = 25
            if power > 0.5 then 
                cache.quick_dash = true
                api:shootOnce(false)
                api:shootOnce(false)
            else
                cache.quick_dash = false
            end
        end
    end
    api:cacheScriptData(cache)
    return false
end

function M.shoot(api)
    api:shootOnce(false)
    if api:getAttachment("STOCK") == "zeta:stock_sup13" then
        local cache = api:getCachedScriptData()
        cache.combo_percent = math.min(cache.combo_percent + 10 , 100)
        api:cacheScriptData(cache)
        if (EXCEPTION_API_EXTENSION_INSTALLED and EXCEPTION_API_EXTENSION_VERSION >= 2) then
            api:dealDamageToClosestEntityByLightning(5, 30, api:getFinalDamage()*0.8, 6, 0.1, 0xEFFEFF, 3)
        end
    end
end

function M.tick_heat(api, heatTimestamp)
    if api:getAmmoAmount()>1 then
        api:removeAmmoFromMagazine(1)
    elseif api:getAmmoAmount()<1 then
        api:putAmmoInMagazine(1)
    end

    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            combo_percent = 0,
            dash_time = 0,
            quick_dash = false
        }
    end
    local t1 = api:getLastShootTimestamp()
    local t2 = api:getCurrentTimestamp()
    local combo_percent = cache.combo_percent or 0
    if (combo_percent > 0)and((t2 - t1 > 1000)) then
        combo_percent = math.max(combo_percent - 1 , 0)
    end
    if (cache.dash_time > 0) then
        cache.dash_time = math.max(cache.dash_time - 1 , 0)
    end
    if (cache.dash_time > 20)and (cache.quick_dash) then
        if (EXCEPTION_API_EXTENSION_INSTALLED and EXCEPTION_API_EXTENSION_VERSION >= 2) then
            if api:getAttachment("STOCK") == "zeta:stock_sup13" then
                api:dealDamageToClosestEntityByLightning(3, 180, api:getFinalDamage()*0.3, 4, 0.1, 0xEFFEFF, 3)
            end
        end
    end
    api:cacheScriptData(cache)
end

function M.modify_property(api, id, original)
    local mode = api:getFireMode()
    if (id == "damage") then
        if api:getAttachment("STOCK") == "zeta:stock_sup13" then
            local cache = api:getCachedScriptData()
            return original * (1 + cache.combo_percent/100)
        end
    end
    if (id == "knockback") then
        local cache = api:getCachedScriptData()
        if cache.dash_time > 22 then
            return original * 12.5
        end
    end
    if (id == "inaccuracy") then
        local cache = api:getCachedScriptData()
        if cache.dash_time > 22 then
            return original * 4.5
        end
    end
    if (id == "ammo_speed") then
        local cache = api:getCachedScriptData()
        if (cache.dash_time > 22)and(cache.quick_dash) then
            return original * 1.5
        end
    end
    return original
end

return M