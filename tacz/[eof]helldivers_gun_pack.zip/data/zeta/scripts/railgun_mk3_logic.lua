--foxatl
local M = {}

function M.start_reload(api)
    if api:getAmmoAmount() == 1 then
        return false
    end
    return true
end

function M.shoot(api)

    local cache = api:getCachedScriptData()
    local progress = api:getChargeProgress()
    if progress >= 50 then
        cache.damage_multiplier = 2.5
    elseif progress >= 10 then
        cache.damage_multiplier = 1.5 * (progress - 10)/40 + 1
    else
        cache.damage_multiplier = 1
    end
    if progress == 60 then
        cache.overCharge = true
    else
        cache.overCharge = false
    end
    api:cacheScriptData(cache)

    api:shootOnce(api:isShootingNeedConsumeAmmo())
end

function M.tick_heat(api,heatTimestamp)
    local cache = api:getCachedScriptData()
    if (cache == nil) then --如果没有就先初始化
        cache = {
            overCharge = false, --是否过蓄
            damage_multiplier = 1
        }
    end

    api:cacheScriptData(cache)
end

function M.modify_property(api, id, original)
    local cache = api:getCachedScriptData()
    if (id == "explosion_radius") then
        if cache.overCharge then
            return 4
        end
    elseif (id == "explosion_damage") then
        if cache.overCharge then
            return 48
        end
    elseif (id == "damage") then
        return original * cache.damage_multiplier
    elseif (id == "explode_enabled") then
        if cache.overCharge then
            return true
        end
    elseif (id == "ammo_speed") then
        if cache.overCharge then
            return 1
        end
    end
    return original
end

function M.handle_shoot_heat(api)
end

function M.calcSpread(api,num,spread)
    local cache = api:getCachedScriptData()
    if cache.overCharge then
        return{0, 0}
    else
        return nil
    end
end

return M