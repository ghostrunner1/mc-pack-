--foxatl
local M = {}

function M.shoot(api)

    local cache = api:getCachedScriptData()
    local progress = api:getChargeProgress()
    if progress >= 20 then
        cache.damage_multiplier = 2.5
    else
        cache.damage_multiplier = 1.5 * (progress)/20 + 1
    end
    if progress >= 20 then
        cache.overCharge = true
    else
        cache.overCharge = false
    end
    api:cacheScriptData(cache)

    api:shootOnce(api:isShootingNeedConsumeAmmo())
end

function M.tick_heat(api,heatTimestamp)
    local cache = api:getCachedScriptData()
    if (cache == nil) then --如果没有就先初始化
        cache = {
            overCharge = false, --是否过蓄
            damage_multiplier = 1
        }
    end

    api:cacheScriptData(cache)
end

function M.modify_property(api, id, original)
    local cache = api:getCachedScriptData()
    if (id == "explosion_radius") then
        if cache.overCharge then
            if (api:getAttachment("STOCK")=="zeta:stock_sup8") then
                return (1.2 * original)
            end
            return 2.5 * original
        end
    elseif (id == "damage") then
        return (original * cache.damage_multiplier)
    elseif (id == "explosion_damage") then
        if cache.overCharge then
            if (api:getAttachment("STOCK")=="zeta:stock_sup8") then
                return (1.2 * original)
            end
            return (4 * original)
        end
    end

    if (id == "burst_shoot_interval") then
        if api:getFireMode() == AUTO then
            return 50
        end
    end
    if (id == "burst_count") then
        if (api:getAttachment("STOCK")=="zeta:stock_sup8") then
            if cache.overCharge then
                return 6
            else
                local multiplier = cache.damage_multiplier
                if (multiplier >= 1.125) then
                    local count = 1 + math.floor(multiplier*2)
                    return count
                else
                    return 2
                end
            end
        end
    end
    return original
end

function M.handle_shoot_heat(api)
end

function M.calcSpread(api,num,spread)
    local cache = api:getCachedScriptData()
    if cache.overCharge then
        return{0, 0}
    else
        return nil
    end
end

return M