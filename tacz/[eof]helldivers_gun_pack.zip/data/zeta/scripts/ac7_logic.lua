local M = {}

function M.shoot(api)
    local cache = api:getCachedScriptData()
    if (cache == nil) then
        cache = {
            frag_count = 0
        }
    end
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    if api:getFireMode() == AUTO then
        cache.frag_count = 30
    else
        cache.frag_count = 0
    end
    api:cacheScriptData(cache)
end
function M.modify_property(api, id, original)
    local mode = api:getFireMode()
    local cache = api:getCachedScriptData()
    if (id == "explosion_radius") then
        if mode == AUTO then
            return original * 1.5
        end
    elseif (id == "explosion_damage") then
        if mode == AUTO then
            return original * 190 / 150
        end
    elseif (id == "damge") then
        if mode == AUTO then
            return original * 150 / 325
        end
    elseif (id == "gunsmithlib_proximity_fuse_distance") then
        if mode == AUTO then
            return 2
        end
    elseif (id == "gunsmithlib_frag_count") then
        return cache.frag_count
    elseif (id == "gunsmithlib_safety_distance") then
        if mode == AUTO then
            return 4
        end
    end
    return original
end

return M