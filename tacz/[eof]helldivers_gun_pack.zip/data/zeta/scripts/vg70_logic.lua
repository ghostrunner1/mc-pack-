local M = {}

local function GunsmithLibShooterStateAllowed()
    if GUNSMITHLIB_INSTALLED == nil then
        return false
    end
    if (GUNSMITHLIB_MAJOR_VERSION >= 6) then
        return true
    else
        return false
    end
end

function M.shoot(api)
    
    local cache = {
        burst = false,
        hurt_power = 0
    }
    api:cacheScriptData(cache)

    if api:getFireMode()==AUTO then
        api:shootOnce(api:isShootingNeedConsumeAmmo())
    elseif api:getFireMode()==SEMI then
        for i = 0, 7-1, 1 do
        api:shootOnce(api:isShootingNeedConsumeAmmo())
        end
    elseif api:getFireMode()==BURST then
        local count = api:getAmmoAmount()
        for i = 0, count-1, 1 do
            api:shootOnce(api:isShootingNeedConsumeAmmo())
        end
        cache.burst = true
        cache.hurt_power = count * 0.125
        api:cacheScriptData(cache)
        api:shootOnce(false)
        api:safeAsyncTask(function ()
            local crawl = false
            if GunsmithLibShooterStateAllowed() then
                local ext = api:gunsmithlib_extension()
                crawl = ext:shooter_states():is_crawling()
            end
            if not crawl then
                if (EXCEPTION_API_EXTENSION_INSTALLED and EXCEPTION_API_EXTENSION_VERSION >= 2) then
                    api:kickbackPlayer(true, count * 0.0375)
                elseif (HEAVY_RECOIL_INSTALLED) then
                    api:kickbackPlayer(api:getShooter(), true, count * 0.0375)
                end
            end
            return false
        end,10,0,1)
    end

end

function M.modify_property(api, id, original)
    local cache = api:getCachedScriptData()
    if (id == "explosion_radius") then
        if cache.burst then
            return cache.hurt_power/6.25
        end
    elseif (id == "explosion_damage") then
        if cache.burst then
            if GunsmithLibShooterStateAllowed() then
                local ext = api:gunsmithlib_extension()
                if ext:shooter_states():is_crawling() then
                    return cache.hurt_power / 2
                end
            end
            return cache.hurt_power
        end
    elseif (id == "explode_enabled") then
        if cache.burst then
            if cache.hurt_power > 0.5 then
                return true
            end
        end
    elseif (id == "explosion_delay") then
        if cache.burst then
            return 0.001
        end
    elseif (id == "ammo_speed") then
        if cache.burst then
            return 0.001
        end
    end
    return original
end

function M.calcSpread(api,num,spread)
    local cache = api:getCachedScriptData()
    if cache.burst then
        return{0, 0}
    else
        return nil
    end
end

return M