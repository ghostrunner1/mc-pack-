-- 脚本的位置是 "{命名空间}:{路径}"，那么 require 的格式为 "{命名空间}_{路径}"
-- 注意！require 取得的内容不应该被修改，应仅调用
local default = require("zeta_plas101_base_state_machine")
local STATIC_TRACK_LINE = default.STATIC_TRACK_LINE
local GUN_KICK_TRACK_LINE = default.GUN_KICK_TRACK_LINE
local MAIN_TRACK = default.MAIN_TRACK

local function runPutAwayAnimation(context)
    local put_away_time = context:getPutAwayTime()
    -- 此处获取的轨道是位于主轨道行上的主轨道
    local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    -- 播放 put_away 动画,并且将其过渡时长设为从上下文里传入的 put_away_time * 0.75
    context:runAnimation("put_away", track, false, PLAY_ONCE_HOLD, put_away_time * 0.75)
    -- 设定动画进度为最后一帧
    context:setAnimationProgress(track, 1, true)
    -- 将动画进度向前拨动 {put_away_time}
    context:adjustAnimationProgress(track, -put_away_time, false)
end

local static_track_top = default.static_track_top

local main_track_states = default.main_track_states
-- main_track_states.idle 是我们要重写的状态。

local idle_state = setmetatable({}, {__index = main_track_states.idle})

local function increment(obj)
    obj.value = obj.value + 1
    return obj.value - 1
end
local LASER_TRACK = increment(static_track_top)

local charge_state = {
    can_charge = true,
    last_progress = 0
}

-- 常态检测（延迟扳机）
function idle_state.update(this, context)
    if (context:isCharging())and(context:getAmmoCount()>0) then
        context:trigger(this.INPUT_CHARING)
    end
end

-- 重写 idle 状态的 transition 函数，将输入 INPUT_CHARING 重定向到新定义的 charge_state 状态
function idle_state.transition(this, context, input)
    -- 进入延迟扳机状态
    if (input == this.INPUT_CHARING) then
        context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK))
        context:runAnimation("charge_in", context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), true, PLAY_ONCE_HOLD, 0)
        return this.main_track_states.charge
    end
    return main_track_states.idle.transition(this, context, input)
end

-- 进入延迟扳机状态
function charge_state.update(this, context)
    if (not context:isCharging())or(context:getAmmoCount()==0) then
        context:trigger(this.INPUT_CHARING_EXIT)
    else
        if context:getChargeProgress() > 0 then
            charge_state.last_progress = context:getChargeProgress()
        end
    end
end

local function isNoAmmo(context)
    -- 这里同时检查了枪管和弹匣
    return (not context:hasBulletInBarrel()) and (context:getAmmoCount() <= 0)
end

-- 播放换弹动画的方法
local function runReloadAnimation(context)
    -- 此处获取的轨道是位于主轨道行上的主轨道
    local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    -- 根据当前整枪内是否还有弹药决定是播放战术换弹还是空枪换弹
    if (isNoAmmo(context)) then
        context:runAnimation("reload_empty", track, false, PLAY_ONCE_STOP, 0.2)
    else
        context:runAnimation("reload_tactical", track, false, PLAY_ONCE_STOP, 0.2)
    end
end

-- 离开延迟扳机状态
function charge_state.transition(this, context, input)
    if (input == INPUT_SHOOT) then
        return this.main_track_states.idle
    end
    if (input == this.INPUT_CHARING_EXIT) then
        context:runAnimation("charge_out", context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), true, PLAY_ONCE_STOP, 0)
        return this.main_track_states.idle
    end
    if (input == INPUT_PUT_AWAY) then
        this.main_track_states.idle.transition(this, context, input)
        return this.main_track_states.idle
    end
end

local laser_track_states = {
    idle = {},
    expand = {},
    lock = false
}

function laser_track_states.idle.transition(this, context, input) --空闲状态，监听射击信号，收到讯息则转入展开状态
    if (input == INPUT_SHOOT) then
        local track = context:findIdleTrack(GUN_KICK_TRACK_LINE, false)
        -- 这里是混合动画，一般是可叠加的 gun kick
        if charge_state.last_progress >= 20 then
            context:runAnimation("shoot_charge", track, true, PLAY_ONCE_STOP, 0)
        end
        return laser_track_states.expand
    end
end

function laser_track_states.expand.entry(this, context) --展开状态，启动激光展开动画
    context:runAnimation("expand_progress", context:getTrack(STATIC_TRACK_LINE, LASER_TRACK), true, PLAY_ONCE_HOLD, 0)
    laser_track_states.lock = false
end

function laser_track_states.expand.update(this, context) --展开状态，侦测射击连续性，中断则输出终止信号
    if  (not context:isCharging()) then
        context:trigger(this.INPUT_LASER_END)
    end
end

function laser_track_states.expand.transition(this, context, input) --展开状态，监听终止信号，收到讯息则转入空闲状态并播放动画
    if (input == this.INPUT_LASER_END)or(input == INPUT_PUT_AWAY) then
        context:runAnimation("expand_ending", context:getTrack(STATIC_TRACK_LINE, LASER_TRACK), true, PLAY_ONCE_STOP, 0)
        laser_track_states.lock = false
        return laser_track_states.idle
    end
    if (input == INPUT_SHOOT) then
        laser_track_states.lock = true
    end
end

-- 用元表的方式继承默认状态机的属性
local M = setmetatable({
    main_track_states = setmetatable({
        idle = idle_state,
        charge = charge_state
    }, {__index = main_track_states}),
    LASER_TRACK = LASER_TRACK,
    GUN_KICK_TRACK_LINE = GUN_KICK_TRACK_LINE,
    laser_track_states = laser_track_states,
    INPUT_RELOAD_RETREAT = "reload_retreat",
    INPUT_CHARING = "input_charging",
    INPUT_CHARING_EXIT = "input_charging_exit",
    INPUT_LASER_END = "input_laser_end"
}, {__index = default})
-- 先调用父级状态机的初始化函数，然后进行自己的初始化
function M:initialize(context)
    default.initialize(self, context)
    self.main_track_states.charge.can_charge = true
    self.laser_track_states.lock = false
    self.laser_track_states.last_progress = 0
    context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, LASER_TRACK))
end
function M:states()
    return {
        self.base_track_state,
        self.bolt_caught_states.normal,
        self.over_heat_states.normal,
        self.main_track_states.start,
        self.gun_kick_state,
        self.movement_track_states.idle,
        self.ADS_states.normal,
        self.slide_states.normal,
        self.laser_track_states.idle
    }
end
-- 导出状态机
return M