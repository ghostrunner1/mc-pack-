# Remove sudafed tag and reset timer
tag @s remove on_sudafed
scoreboard players set @s sudafed_time 0
scoreboard players set @s sudafed_dose 0

# Clear effects
effect clear @s minecraft:speed
effect clear @s minecraft:haste
effect clear @s minecraft:jump_boost
effect clear @s minecraft:night_vision
effect clear @s minecraft:regeneration

# Clean fade-out particles
execute at @s run particle minecraft:cloud ~ ~1 ~ 0.3 0.3 0.3 0.05 8

# Farewell message
title @s actionbar {"text":"The buzz fades. Back to reality.","color":"dark_gray","italic":true}
execute at @s run playsound minecraft:block.amethyst_block.break ambient @s ~ ~ ~ 0.4 0.6
