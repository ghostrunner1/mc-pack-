# Revoke the advancement so it can trigger again
advancement revoke @s only trippy:ate_cyanide

# Apply deadly effects
effect give @s minecraft:wither 30 4 true
effect give @s minecraft:poison 30 4 true
effect give @s minecraft:nausea 15 4 true
effect give @s minecraft:blindness 30 0 true
effect give @s minecraft:slowness 30 4 true

# Play sounds
execute at @s run playsound minecraft:entity.player.hurt ambient @s ~ ~ ~ 1.0 0.5
execute at @s run playsound minecraft:entity.wither.ambient ambient @s ~ ~ ~ 0.5 0.5

# Visual particles
execute at @s run particle minecraft:dust{color:[0.1,0.1,0.1],scale:2.0} ~ ~1 ~ 0.5 0.5 0.5 0.1 100
execute at @s run particle minecraft:smoke ~ ~1 ~ 0.5 0.5 0.5 0.1 50

# Deal magic damage immediately just to make sure they die fast
damage @s 100 minecraft:magic

# Announce actionbar
title @s actionbar {"text":"You shouldn't have eaten that...","color":"dark_red","bold":true}
