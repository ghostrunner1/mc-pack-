# Heart palpitation event - triggered on 3+ doses in a row
# Darkness + Slowness III flash to simulate a racing heart
effect give @s minecraft:slowness 3 2 true
effect give @s minecraft:darkness 2 0 true

# Violent particle burst
execute at @s run particle minecraft:dust{color:[1.0,0.1,0.1],scale:1.5} ~ ~1 ~ 0.5 0.5 0.5 0.1 40
execute at @s run particle minecraft:poof ~ ~1 ~ 0.4 0.4 0.4 0.1 20

# Heartbeat sound
execute at @s run playsound minecraft:block.bell.use ambient @s ~ ~ ~ 1.0 0.3
execute at @s run playsound minecraft:block.bell.use ambient @s ~ ~ ~ 0.8 0.4

# GUI flash
title @s times 0 15 5
title @s title {"text":"♥","color":"red","bold":true}
title @s subtitle {"text":"Your heart can't keep up!","color":"dark_red","italic":true}

# Grant the hidden achievement
advancement grant @s only trippy:achievements/overdose
