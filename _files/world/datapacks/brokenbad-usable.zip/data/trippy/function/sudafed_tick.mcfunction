# Decrement sudafed timer
scoreboard players remove @s sudafed_time 1

# Fade out check — end the sudafed session
execute if score @s sudafed_time matches ..0 run function trippy:sudafed_end

# While active: light shimmer particle trail + occasional heart-rate jitters
execute if score @s sudafed_time matches 1.. run function trippy:sudafed_active
