# Revoke the advancement so it can trigger again
advancement revoke @s only trippy:ate_sudafed

# --- STACK COUNTER ---
# Increment sudafed dose counter (decays over time via sudafed_tick)
scoreboard players add @s trip_rand 0
scoreboard objectives add sudafed_dose dummy "Sudafed Doses"
scoreboard players add @s sudafed_dose 1

# Set/reset the sudafed active timer (400 ticks = 20 seconds)
scoreboard players set @s sudafed_time 400

# Add on_sudafed tag so the tick loop picks this player up
tag @s add on_sudafed

# --- INITIAL BRIEF NAUSEA HEAD-RUSH ---
effect give @s minecraft:nausea 3 0 true

# --- STIMULANT EFFECTS ---
effect give @s minecraft:speed 20 1 true
effect give @s minecraft:haste 20 0 true
effect give @s minecraft:jump_boost 20 0 true
effect give @s minecraft:night_vision 15 0 true
effect give @s minecraft:regeneration 10 0 true

# --- PARTICLES BURST ON CONSUME ---
execute at @s run particle minecraft:dust{color:[0.85,0.85,1.0],scale:1.0} ~ ~1 ~ 0.4 0.4 0.4 0.05 30
execute at @s run particle minecraft:cloud ~ ~1 ~ 0.3 0.3 0.3 0.05 10

# --- SOUND ---
execute at @s run playsound minecraft:entity.player.burp ambient @s ~ ~ ~ 0.8 1.2
execute at @s run playsound minecraft:block.amethyst_block.chime ambient @s ~ ~ ~ 0.5 1.8

# --- STACK WARNING CHECK ---
execute if score @s sudafed_dose matches 3.. run function trippy:sudafed_palpitation

# --- ACTIONBAR HINT ---
execute if score @s sudafed_dose matches 1 run title @s actionbar {"text":"Pseudoephedrine... mild buzz.","color":"gray","italic":true}
execute if score @s sudafed_dose matches 2 run title @s actionbar {"text":"Double dose... heart's picking up.","color":"yellow","italic":true}
execute if score @s sudafed_dose matches 3.. run title @s actionbar {"text":"Your heart is racing...","color":"red","bold":true}

# --- CRAFTING GATEWAY HINT (first dose only) ---
execute if score @s sudafed_dose matches 1 run tellraw @s {"text":"[?] You wonder what this stuff could be cooked into...","color":"dark_gray","italic":true}
