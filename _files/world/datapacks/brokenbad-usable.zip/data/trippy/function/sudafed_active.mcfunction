# Roll a random number for jitter events (1 in 80 = roughly once every 4 seconds)
execute store result score @s trip_rand run random value 1..80

# Shimmer particle trail (every tick, subtle)
execute at @s run particle minecraft:dust{color:[0.85,0.85,1.0],scale:0.8} ~ ~1 ~ 0.2 0.4 0.2 0.02 1

# Random heart-rate jitter: brief Speed X (adrenaline spike)
execute if score @s trip_rand matches 1 run effect give @s minecraft:speed 1 8 true
execute if score @s trip_rand matches 1 run effect give @s minecraft:jump_boost 1 3 true
execute if score @s trip_rand matches 1 at @s run playsound minecraft:block.amethyst_block.chime ambient @s ~ ~ ~ 0.3 2.0

# Random jitter: brief slowdown (palpitation)
execute if score @s trip_rand matches 2 run effect give @s minecraft:slowness 2 1 true
execute if score @s trip_rand matches 2 at @s run playsound minecraft:block.bell.use ambient @s ~ ~ ~ 0.4 0.5

# Actionbar shimmer status (every 40 ticks = every 2 seconds)
execute if score @s sudafed_time matches 360 run title @s actionbar {"text":"● Pseudoephedrine active","color":"aqua","italic":true}
execute if score @s sudafed_time matches 200 run title @s actionbar {"text":"● Wearing off...","color":"gray","italic":true}
execute if score @s sudafed_time matches 60 run title @s actionbar {"text":"● Fading...","color":"dark_gray","italic":true}
