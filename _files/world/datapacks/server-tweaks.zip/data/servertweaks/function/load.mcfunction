gamerule doInsomnia false
schedule function servertweaks:safezone 20t replace
