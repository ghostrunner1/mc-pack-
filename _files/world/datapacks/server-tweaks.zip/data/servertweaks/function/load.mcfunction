gamerule doInsomnia false
