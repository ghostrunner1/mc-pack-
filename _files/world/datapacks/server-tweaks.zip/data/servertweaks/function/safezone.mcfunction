# Safe zone: chunks -93;140 .. -69;177 = blocks x -1488..-1089, z 2240..2847, full height
execute as @e[type=cave_dweller:cave_dweller,x=-1488,y=-64,z=2240,dx=399,dy=384,dz=607] at @s run tp @s ~ -1000 ~
execute as @e[type=skinwalker:skinwalker,x=-1488,y=-64,z=2240,dx=399,dy=384,dz=607] at @s run tp @s ~ -1000 ~
schedule function servertweaks:safezone 20t replace
