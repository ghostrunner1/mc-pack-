# Safe zone: remove horror mobs inside the base area. Zones are filled in below.
# ZONES_START
# ZONES_END
schedule function servertweaks:safezone 20t replace
